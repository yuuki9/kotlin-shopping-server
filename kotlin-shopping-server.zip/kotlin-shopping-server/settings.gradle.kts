rootProject.name = "kotlin-shopping-server"
